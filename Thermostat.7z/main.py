import os
import sys
import temperature
import display

import subprocess
from datetime import datetime
import time

GAIN = 1
MAX_START = 0xffff

user = os.getuid()
if user != 0:
    print("Please run script as root")
    sys.exit()


def main(argv):
    stuff=display.Display()
    temperature.temp_sensor_found()
    stuff.update_entire_screen('cool', '23', '66')


# main
if "__main__" == __name__:
    if len(sys.argv) < 1:
        sys.exit('usage: {p:s}'.format(p=sys.argv[0]))

    try:
        main(sys.argv[1:])
    except KeyboardInterrupt:
        sys.exit('interrupted')
        pass
