import RPi.GPIO as GPIO
import constants
from papirus import Papirus

papirus_eink_display = Papirus()
 
def init_hardware():
    GPIO.cleanup()  # cleanup all GPIO
    papirus_eink_display.use_lm75b=False
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(constants.compressor, GPIO.OUT)
    GPIO.setup(constants.heat, GPIO.OUT)
    GPIO.setup(constants.low_fan, GPIO.OUT)
    GPIO.setup(constants.high_fan, GPIO.OUT)
    GPIO.setup(constants.mode, GPIO.IN)
    GPIO.setup(constants.up, GPIO.IN)
    GPIO.setup(constants.dn, GPIO.IN)




