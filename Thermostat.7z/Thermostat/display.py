from papirus import Papirus
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
import constants

papirus_eink_display = Papirus()
 
class Display:

    # create  an image to match eink display dimensions
    def __init__(self):
        self._image=self.__get_base_image()


    # Updates the current temperature with full screen update
    def update_temp(self, temperature):
        """
        :param temperature:
        """
        draw=ImageDraw.Draw(self._image)

        draw.rectangle((85, 30, 200, 70), fill=constants.WHITE, outline=constants.WHITE)
        draw.text((85, 30), "{0}\xb0".format(temperature), font=constants.temp_font)
        bw = self._image.convert("1", dither=Image.FLOYDSTEINBERG)
        papirus_eink_display.display(bw)
        papirus_eink_display.partial_update()


    # create a default image to use the size of the connected eink display
    def __get_base_image(self):
        image=Image.new('1', papirus_eink_display.size, constants.WHITE)
        width, height=image.size
        img=Image.open('/home/pi/TempGauage/image/coldDisp.bmp', 'r')
        return img

    # partial screen update of the selected desired temperature
    def update_temp_setting(self, selected_setting):
        """

        :param selected_setting:
        """
        draw=ImageDraw.Draw(self._image)
        draw.text((30, 40), "{0}".format(selected_setting), font=constants.temp_font)

        bw=self._image.convert("1", dither=Image.FLOYDSTEINBERG)
        papirus_eink_display.display(bw)
        papirus_eink_display.partial_update()

    # clear the eink display
    def clear_screen(self):
        papirus_eink_display.clear()

    # partial screen update of mode
    def update_mode(self, selected_mode):
        """

        """
        papirus_eink_display.clear()

    # update all components on the page instead of a partial update - this will cause a "page refresh"
    def update_entire_screen(self, selected_mode, seleted_setting, current_temperature):
        """

        :param current_temperature:
        :param seleted_setting:
        :param selected_mode:
        """
        draw=ImageDraw.Draw(self._image)
        draw.text((30, 40), "{0}|".format(seleted_setting), font=constants.setting_font)
        draw.text((85, 30), "{0}\xb0".format(current_temperature), font=constants.temp_font)
        draw.text((150, 70), "{0}".format(selected_mode), font=constants.description_font)

        bw=self._image.convert("1", dither=Image.FLOYDSTEINBERG)
        self.__eink_full_update(bw)

    # write error message to entire screen
    def write_error(self, error_text):
        """
        :param error_text:
        """
        current_line=0  # type: int
        # unicode by default
        display_text=[""]
        papirus_eink_display.clear()
        draw=ImageDraw.Draw(self._image)
        for w in error_text.split():
            # Always add first w (even when it is too long)
            if len(display_text[current_line]) == 0:
                display_text[current_line] += w
            elif (
                    draw.textsize(display_text[current_line] + " " + w, font=constants.descriptionFont)[
                        0]) < papirus_eink_display.width:
                display_text[current_line] += " " + w
            else:
                # No space left on line so move to next one
                display_text.append("")
                current_line+=1
                display_text[current_line] += w

        current_line=0
        for l in display_text:
            draw.text((0, 20 * current_line), l, font=constants.descriptionFont, fill=constants.BLACK)
            current_line += 1
        current_line = 0
        img=self.__get_base_image()
        draw=ImageDraw.Draw(img)
        for line in display_text:
            draw.text((0, constants.descriptionFont_SIZE * current_line), line, font=constants.descriptionFont,
                      fill=constants.BLACK)
            current_line += 1
        self.__eink_full_update(img)

    # full screen update screen with text
    def __eink_full_update(self, display_image):
        """
        :param display_image:
        """
        mode1_image=display_image.convert("1", dither=Image.FLOYDSTEINBERG)  # convert image to black and white
        papirus_eink_display.display(mode1_image)
        papirus_eink_display.update()
