import os
import subprocess
from datetime import datetime
import time
import glob
import constants

class TemperatureSensor:
    __temp_sensor = ""  # holds the path to the temp sensor in the devices folder
    __status = "offline"  # status of the temp sensor - if found the status is online otherwise offline

    @property
    def status(self):
        return self.__status

    def __init__(self):
        # confirm the 1wire module is loaded and the sensor is found
        if self.module_loaded('w1') and self.temp_sensor_found():
            base_dir='/sys/bus/w1/devices/'
            device_folder = glob.glob(base_dir + '28*')[0]
            self.__temp_sensor = device_folder + '/w1_slave'
            self.__status = "online"

    def temp_sensor_found(self):
        found = False
        path = '/sys/bus/w1/devices/28-*/w1_slave' # temp sensor will be in a folder starting the the pattern 28* under w1_slave
        result = glob.glob(path) # returns a list of matches
        if len(result) > 0:
            __temp_sensor = result[0] # in this case there is only a single sensor
            found = True              # so reading the first sensor in the list and store
        return found


    # confirms the passed module is loaded
    def module_loaded(self, module_name):
        lsmod_proc = subprocess.Popen(['lsmod'], stdout=subprocess.PIPE)  # retrieve a list of modules
        grep_proc = subprocess.Popen(['grep', module_name], stdin=lsmod_proc.stdout) # search for the module requested
        grep_proc.communicate()  # Block until finished
        return grep_proc.returncode == 0

    def read_temp_raw(self):
        try:
            f = open(self.__temp_sensor, 'r')  # open the temp sensor file
        except OSError:
            return -999
        lines = f.readlines()  # there will be a 2 lines with data from the sensor
        f.close()
        return lines

        # reads the temperature from the sensor and returns value in celsius
    def read_temp(self, temperature_format=constants.celsius):
        lines = self.read_temp_raw()
        if len(lines) > 0:
            while lines[0].strip()[-3:] != 'YES':  # read till we get a successful CRC result
                time.sleep(0.1)
                lines = self.read_temp_raw()
            equals_pos = lines[1].find('t=')  # the temp will be preceded with t=
            if equals_pos != -1:
                temp_string = lines[1][equals_pos + 2:]
                temp_c = float(temp_string) / 1000.0
                if temperature_format == constants.fahrenheit:
                    return int(temp_c * 9.0 / 5.0 + 32.0)
                else:
                    return int(temp_c)
