from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

#Display configuration
temp_font_size=40
setting_font_size=35
description_font_size=20

# configure fonts
FONT_FILE='/usr/share/fonts/truetype/freefont/FreeSerif.ttf'
FONT_BOLD='/usr/share/fonts/truetype/freefont/FreeSerif.ttf'
TIME_FONT='/usr/share/fonts/truetype/freefont/FreeSerif.ttf'

temp_font=ImageFont.truetype(FONT_FILE, temp_font_size)
setting_font=ImageFont.truetype(FONT_FILE, setting_font_size)
description_font=ImageFont.truetype(FONT_BOLD, description_font_size)

WHITE=255
BLACK=0

#Temperature configuration
celsius = 0
fahrenheit =1

#Hardware Configuration
ds18b20= 7 # this is the default 1 wire pin, not used in the code, here for documentation
low_fan=38
high_fan=36
compressor=15
heat=12
mode=3
up=40
dn=29

