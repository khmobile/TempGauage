import os
import sys
import temperature
import display
import subprocess
from datetime import datetime
import time
import constants
import hardware
import RPi.GPIO as GPIO

GAIN = 1
MAX_START = 0xffff

user=os.getuid()
if user != 0:
    print("script must run as root")
    sys.exit()


def main(argv):
    hardware.init_hardware()
  #  GPIO.output(constants.compressor, GPIO.HIGH)
   # GPIO.output(constants.heat, GPIO.LOW)

    GPIO.output(constants.high_fan, GPIO.HIGH)
    GPIO.output(constants.low_fan, GPIO.HIGH)
    GPIO.output(constants.heat, GPIO.HIGH)

    disp=display.Display()
    disp.clear_screen()
    disp.update_entire_screen("cool", 71, '')
    while 1 == 1:  # loop forever
        stuff=temperature.TemperatureSensor()
        temp_f=stuff.read_temp(constants.fahrenheit)
        if temp_f is not None:
            disp.update_temp(temp_f)
            time.sleep(3)


# main
if "__main__" == __name__:
    if len(sys.argv) < 1:
        sys.exit('usage: {p:s}'.format(p=sys.argv[0]))
    try:
        main(sys.argv[1:])
    except KeyboardInterrupt:
        sys.exit('interrupted')
        pass
