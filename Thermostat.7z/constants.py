from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

temp_font_size=50
setting_font_size=40
description_font_size=20

WHITE=1
BLACK=0

# configure fonts
FONT_FILE='/usr/share/fonts/truetype/freefont/FreeSerif.ttf'
FONT_BOLD='/usr/share/fonts/truetype/freefont/FreeSerif.ttf'
TIME_FONT='/usr/share/fonts/truetype/freefont/FreeSerif.ttf'

temp_font=ImageFont.truetype(FONT_FILE, temp_font_size)
setting_font=ImageFont.truetype(FONT_FILE, setting_font_size)
description_font=ImageFont.truetype(FONT_BOLD, description_font_size)
